#include <print.hpp>

int main(int argc, char** argv)
{
  print("hello");
}
